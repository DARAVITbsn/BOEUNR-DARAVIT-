import type { PackageJSON, Packument, PackumentVersion } from '@npm/types';
import { gt, satisfies } from 'semver';
import HttpError from './HttpError.ts';
import Module from './Module.ts';
import {
  cachePackument,
  getCachedPackument,
  getNPMPackument,
} from './PackumentCache.ts';
import type { PromiseWithResolversType } from './PromiseWithResolvers.ts';
import PromiseWithResolvers from './PromiseWithResolvers.ts';
import { PARAM_PACKAGES } from './constants.ts';
import fetchJSON from './fetchJSON.ts';
import { flash } from './flash.ts';
import {
  getModuleKey,
  isHttpModule,
  parseModuleKey,
  resolveModule,
} from './module_util.ts';
import { hashGet } from './url_util.ts';
import { getRegistry } from './useRegistry.ts';

const moduleCache = new Map<string, ModuleCacheEntry>();

export enum QueryType {
  Default = '',
  Exact = 'exact', // deprecated - use Default
  Name = 'name', // deprecated - use Default
  License = 'license',
  Maintainer = 'maintainer',
}

type ModuleCacheEntry = PromiseWithResolversType<Module> & {
  module: Module; // Set once module is loaded
  registry?: string; // NPM_REGISTRY url
};

function selectVersion(
  packument: Packument,
  targetVersion: string = 'latest',
): PackumentVersion | undefined {
  let selectedVersion: string | undefined;

  // If version matches a dist-tag (e.g. "latest", "best", etc), use that
  const distVersion = packument['dist-tags']?.[targetVersion];
  if (distVersion) {
    selectedVersion = distVersion;
  } else {
    // Find highest matching version
    for (const version of Object.keys(packument.versions)) {
      if (!satisfies(version, targetVersion)) continue;
      if (!selectedVersion || gt(version, selectedVersion)) {
        selectedVersion = version;
      }
    }
  }

  return packument.versions[selectedVersion ?? 'undefined'];
}

async function fetchModuleFromNPM(
  moduleName: string,
  version?: string,
): Promise<Module> {
  const packument = await getNPMPackument(moduleName);

  if (!packument) {
    throw new Error(`Could not find ${moduleName} module`);
  }

  // Match best version from manifest
  const packumentVersion = packument && selectVersion(packument, version);

  if (!packumentVersion) {
    throw new Error(`${moduleName} does not have a version ${version}`);
  }

  return new Module(packumentVersion, packument);
}

async function fetchModuleFromURL(urlString: string) {
  const url = new URL(urlString);

  // TODO: We should probably be fetching github content via their REST API, but
  // that makes this code much more github-specific.  So, for now, we just do
  // some URL-massaging to pull from the "raw" URL
  if (/\.?github.com$/.test(url.host)) {
    url.host = 'raw.githubusercontent.com';
    url.pathname = url.pathname.replace('/blob', '');
  }
  const pkg: PackageJSON = await fetchJSON<PackageJSON>(url);

  if (!pkg.name) pkg.name = url.toString();

  return new Module(pkg as PackumentVersion);
}

// Note: This method should not throw!  Errors should be returned as part of a
// stub module
export async function getModule(moduleKey: string): Promise<Module> {
  if (!moduleKey) throw new Error('Undefined module name');

  let [name, version] = parseModuleKey(moduleKey);

  if (isHttpModule(moduleKey)) {
    name = moduleKey;
    version = '';
    // unchanged
  } else {
    [name, version] = resolveModule(name, version);
  }

  moduleKey = getModuleKey(name, version);
  // Check cache once we're done massaging the version string
  const cachedEntry = moduleCache.get(moduleKey);
  if (cachedEntry && cachedEntry.registry === getRegistry()) {
    return cachedEntry.promise;
  }

  // Set up the cache so subsequent requests for this module will get the same
  // promise object (and thus the same module), even if the module hasn't been
  // loaded yet
  const cacheEntry = PromiseWithResolvers() as ModuleCacheEntry;
  moduleCache.set(moduleKey, cacheEntry);

  let promise: Promise<Module>;

  // Fetch module based on type
  if (isHttpModule(moduleKey)) {
    promise = fetchModuleFromURL(moduleKey);
  } else {
    cacheEntry.registry = getRegistry();
    promise = fetchModuleFromNPM(name, version);
  }
  promise
    .catch(err => {
      if (err instanceof HttpError) {
        err.message = `Fetch failed for ${moduleKey} (code = ${err.code})`;
      }

      return Module.stub(moduleKey, err);
    })
    .then(module => {
      cacheEntry.module = module;

      // Add cache entry for module's computed key
      moduleCache.set(module.key, cacheEntry);

      // Resolve promise
      cacheEntry.resolve(module);
    });

  return cacheEntry.promise;
}

export function getCachedModule(key: string) {
  const entry = moduleCache.get(key);
  return entry && entry.registry === getRegistry() ? entry.module : undefined;
}

export function cacheModule(module: Module, registry?: string) {
  const moduleKey = module.key;
  const entry = moduleCache.get(moduleKey);

  if (entry && entry?.registry === registry) {
    entry.resolve(module);
  } else {
    moduleCache.set(moduleKey, {
      promise: Promise.resolve(module),
      module,
      registry,
      resolve() {},
      reject() {},
    });
  }
}

/**
 * Convenience method for getting loaded modules by some criteria.
 */
export function queryModuleCache(queryType: QueryType, queryValue: string) {
  const results = new Map<string, Module>();

  if (!queryType && !queryValue) return results;

  // 'exact' and 'name' query deprecated in favor of Default
  if (queryType === QueryType.Exact) {
    queryType = QueryType.Default;
  } else if (queryType === QueryType.Name) {
    queryType = QueryType.Default;
  }

  for (const { module } of moduleCache.values()) {
    if (!module) continue;

    switch (queryType) {
      case QueryType.Default: {
        const [name, version] = parseModuleKey(queryValue);
        if (
          module.name === name &&
          (!version || satisfies(module.version, version))
        ) {
          results.set(module.key, module);
        }
        break;
      }
      case QueryType.License:
        if (module.getLicenses().includes(queryValue.toLowerCase()))
          results.set(module.key, module);
        break;
      case QueryType.Maintainer:
        if (module.maintainers.find(({ name }) => name === queryValue))
          results.set(module.key, module);
        break;
    }
  }

  return results;
}

const PACKAGE_WHITELIST: (keyof PackageJSON)[] = [
  'author',
  'dependencies',
  'devDependencies',
  'license',
  'name',
  'peerDependencies',
  'peerDependenciesMeta',
  'version',
];

export function sanitizePackageKeys(pkg: PackageJSON) {
  const sanitized: PackageJSON = {} as PackageJSON;

  for (const key of PACKAGE_WHITELIST) {
    if (key in pkg) (sanitized[key] as unknown) = pkg[key];
  }

  return sanitized;
}

export function cacheLocalPackage(pkg: PackumentVersion) {
  let packument = getCachedPackument(pkg.name);
  if (!packument) {
    const now = new Date().toISOString();
    // Create a stub packument
    packument = {
      name: pkg.name,
      versions: {},
      'dist-tags': {},
      maintainers: [],
      time: {
        modified: now,
        created: now,
        [pkg.version]: now,
      },
      license: pkg.license ?? 'UNLICENSED',
    } as unknown as Packument;

    // Put it into the packument cache
    cachePackument(pkg.name, packument);
  }

  // Add version to packument
  packument.versions[pkg.version] = pkg;

  const module = new Module(pkg);

  module.isLocal = true;

  // Put module in cache and local cache
  cacheModule(module);

  return module;
}

let lastPackagesVal: string | null;

// Make sure any packages in the URL hash are loaded into the module cache
export function syncPackagesHash() {
  const packagesJson = hashGet(PARAM_PACKAGES);

  // If the hash param hasn't changed, there's nothing to do
  if (lastPackagesVal === packagesJson) return;
  lastPackagesVal = packagesJson;

  if (!packagesJson) return;

  let packages: PackageJSON[];
  try {
    packages = JSON.parse(packagesJson);
  } catch {
    flash('"packages" hash param is not valid JSON');
    return;
  }

  for (const pkg of packages) {
    cacheLocalPackage(pkg as PackumentVersion);
  }
}
